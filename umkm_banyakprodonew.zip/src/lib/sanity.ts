import { createClient } from '@sanity/client';

export const sanityClient = createClient({
  projectId: import.meta.env.PUBLIC_SANITY_PROJECT_ID,
  dataset: import.meta.env.PUBLIC_SANITY_DATASET,
  apiVersion: '2024-01-01',
  useCdn: true,
});

const QUERY_ALL_UMKM = `*[_type == "umkm"] | order(nama asc) {
  "id": slug.current,
  nama,
  kategori,
  pemilik,
  telepon,
  harga,
  deskripsi,
  halal,
  nib,
  nomorNib,
  "galeri": galeri[].asset->url,
  maps,
  instagram,
  facebook,
  tiktok,
  video,
  dusun,
  alamatDetail,
  jamOperasional,
  pembayaran
}`;

export async function getUmkmData() {
  return await sanityClient.fetch(QUERY_ALL_UMKM);
}